package hello;

// This is considered as the Leaf class of The Composite Desing Pattern.
// It holds the items.

public class item{
    public String name;
    public String itemDescription;
    public double price;
    public String days;
    public String startDate;
    public String endDate;

    public String RankkingDate1;
    public String RankkingDate2;
    public int ranking;
}